@echo off
setlocal EnableExtensions
chcp 65001 >nul
title EST Quant Dashboard

cd /d "%~dp0"

echo.
echo ══════════════════════════════════════════════════════════════
echo   EST Quant / Tele Quant - Windows Dashboard Runner
echo ══════════════════════════════════════════════════════════════
echo.

if not exist "pyproject.toml" (
    echo [ERROR] pyproject.toml 파일이 없습니다.
    echo 이 run.bat 파일을 est_quant 프로젝트 최상위 폴더에 넣고 실행하세요.
    echo.
    pause
    exit /b 1
)

if not exist "data\private" mkdir "data\private"
if not exist "logs" mkdir "logs"

call :ensure_uv
if errorlevel 1 exit /b 1

echo.
echo [1/4] Python 3.12 준비 중...
uv python install 3.12
if errorlevel 1 (
    echo [ERROR] Python 3.12 설치/확인 실패
    pause
    exit /b 1
)

if not exist ".env.local" (
    echo.
    echo [2/4] .env.local 파일이 없어서 새로 만듭니다.
    if exist "env.example" (
        copy /Y "env.example" ".env.local" >nul
    ) else if exist "env.template" (
        copy /Y "env.template" ".env.local" >nul
    ) else (
        echo [ERROR] env.example 또는 env.template 파일이 없습니다.
        pause
        exit /b 1
    )
    echo.
    echo .env.local 이 생성되었습니다.
    echo 메모장이 열리면 TELEGRAM_BOT_TOKEN / TELEGRAM_BOT_TARGET_CHAT_ID 등을 입력하세요.
    echo 입력 후 저장하고, 이 run.bat을 다시 더블클릭하면 됩니다.
    echo.
    start "" notepad ".env.local"
    pause
    exit /b 0
)

echo.
echo [2/4] 패키지 설치/동기화 중...
if exist "uv.lock" (
    uv sync --python 3.12 --locked
    if errorlevel 1 (
        echo.
        echo [WARN] locked sync 실패. 일반 uv sync로 재시도합니다.
        uv sync --python 3.12
    )
) else (
    uv sync --python 3.12
)
if errorlevel 1 (
    echo [ERROR] 패키지 설치 실패
    echo 네트워크, Python, uv 설치 상태를 확인하세요.
    pause
    exit /b 1
)

echo.
echo [3/4] 브라우저를 엽니다: http://127.0.0.1:8765
start "" "http://127.0.0.1:8765"

echo.
echo [4/4] 대시보드 실행 중입니다. 종료하려면 이 창에서 Ctrl+C를 누르세요.
echo.
uv run --python 3.12 tele-quant dashboard --host 127.0.0.1 --port 8765

echo.
echo 대시보드가 종료되었습니다.
pause
exit /b 0

:ensure_uv
where uv >nul 2>nul
if not errorlevel 1 (
    echo [OK] uv 설치 확인
    exit /b 0
)

echo [INFO] uv가 없어 설치합니다...
powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://astral.sh/uv/install.ps1 | iex"
set "PATH=%USERPROFILE%\.local\bin;%USERPROFILE%\.cargo\bin;%PATH%"

where uv >nul 2>nul
if errorlevel 1 (
    echo.
    echo [ERROR] uv 설치 후에도 uv 명령을 찾지 못했습니다.
    echo 새 명령 프롬프트를 열거나 PC를 재시작한 뒤 다시 실행해보세요.
    pause
    exit /b 1
)

echo [OK] uv 설치 완료
exit /b 0
