@echo off
setlocal EnableExtensions
chcp 65001 >nul
title EST Quant Telegram Auth

cd /d "%~dp0"

if not exist ".env.local" (
    echo [ERROR] .env.local 파일이 없습니다. 먼저 run.bat 또는 install.bat을 실행하세요.
    pause
    exit /b 1
)

where uv >nul 2>nul
if errorlevel 1 (
    echo [ERROR] uv가 없습니다. 먼저 install.bat을 실행하세요.
    pause
    exit /b 1
)

echo 텔레그램 사용자 계정 인증을 시작합니다.
echo my.telegram.org의 TELEGRAM_API_ID / TELEGRAM_API_HASH / TELEGRAM_PHONE 이 필요합니다.
echo.
uv run --python 3.12 tele-quant auth
pause
