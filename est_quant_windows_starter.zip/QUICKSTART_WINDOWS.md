# EST Quant Windows 빠른 실행

## 목적

다운로드한 사람이 복잡한 명령어 없이 아래 흐름으로 실행하게 만드는 구성입니다.

1. 저장소 ZIP 다운로드 또는 git clone
2. `env.example`을 `.env.local`로 복사하거나 `run.bat` 첫 실행으로 자동 생성
3. `.env.local`에 텔레그램/API 값 입력
4. `run.bat` 더블클릭
5. 브라우저에서 `http://127.0.0.1:8765` 접속

## 넣을 파일

이 묶음의 파일들을 `pyproject.toml`이 있는 프로젝트 최상위 폴더에 넣으세요.

```text
run.bat
install.bat
auth_telegram.bat
preview_kr.bat
env.example
QUICKSTART_WINDOWS.md
```

## 사용자 안내 문구 예시

```text
1. run.bat을 더블클릭하세요.
2. 처음 실행하면 .env.local 파일이 자동 생성되고 메모장이 열립니다.
3. TELEGRAM_BOT_TOKEN, TELEGRAM_BOT_TARGET_CHAT_ID 등을 입력하고 저장하세요.
4. run.bat을 다시 더블클릭하세요.
5. 브라우저에서 대시보드가 열립니다.
```

## 필수에 가까운 값

봇으로 텔레그램 전송까지 하려면 아래 2개가 필요합니다.

```env
TELEGRAM_BOT_TOKEN=
TELEGRAM_BOT_TARGET_CHAT_ID=
```

텔레그램 채널을 수집하려면 아래 4개도 필요합니다.

```env
TELEGRAM_API_ID=
TELEGRAM_API_HASH=
TELEGRAM_PHONE=
TELEGRAM_SOURCE_CHATS=
```

DART 키 이름은 `DART_API_KEY`가 아니라 현재 코드 기준 `OPENDART_API_KEY`를 쓰는 쪽이 맞습니다.

```env
OPENDART_ENABLED=true
OPENDART_API_KEY=
```

## 현재 저장소에서 같이 고치면 좋은 점

README와 Windows 문서에는 `.env.example`을 복사하라고 되어 있지만 실제 저장소에는 `env.template`가 있습니다. 배포용으로는 `env.example` 파일을 추가하고 README의 설치 부분을 `copy env.example .env.local`로 맞추는 편이 좋습니다.

Windows 문서에는 예전 프로젝트명인 `modoo` 경로가 남아 있습니다. `est_quant` 기준으로 바꾸는 것이 좋습니다.

`TELEGRAM_SESSION_PATH=./data`는 배포용으로 헷갈립니다. `./data/private/tele_quant.session`처럼 파일 경로로 고정하는 편이 좋습니다.
