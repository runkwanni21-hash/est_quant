@echo off
setlocal EnableExtensions
chcp 65001 >nul
title EST Quant Installer

cd /d "%~dp0"

echo.
echo ══════════════════════════════════════════════════════════════
echo   EST Quant / Tele Quant - Installer
echo ══════════════════════════════════════════════════════════════
echo.

if not exist "pyproject.toml" (
    echo [ERROR] pyproject.toml 파일이 없습니다.
    echo 이 install.bat 파일을 est_quant 프로젝트 최상위 폴더에 넣고 실행하세요.
    pause
    exit /b 1
)

if not exist "data\private" mkdir "data\private"
if not exist "logs" mkdir "logs"

where uv >nul 2>nul
if errorlevel 1 (
    echo [INFO] uv 설치 중...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://astral.sh/uv/install.ps1 | iex"
    set "PATH=%USERPROFILE%\.local\bin;%USERPROFILE%\.cargo\bin;%PATH%"
)

where uv >nul 2>nul
if errorlevel 1 (
    echo [ERROR] uv를 찾지 못했습니다. 새 터미널 또는 재부팅 후 다시 실행하세요.
    pause
    exit /b 1
)

echo [1/3] Python 3.12 준비 중...
uv python install 3.12
if errorlevel 1 (
    echo [ERROR] Python 3.12 준비 실패
    pause
    exit /b 1
)

echo [2/3] 패키지 설치/동기화 중...
if exist "uv.lock" (
    uv sync --python 3.12 --locked
    if errorlevel 1 (
        echo [WARN] locked sync 실패. 일반 uv sync로 재시도합니다.
        uv sync --python 3.12
    )
) else (
    uv sync --python 3.12
)
if errorlevel 1 (
    echo [ERROR] 패키지 설치 실패
    pause
    exit /b 1
)

if not exist ".env.local" (
    echo [3/3] .env.local 생성
    if exist "env.example" (
        copy /Y "env.example" ".env.local" >nul
    ) else if exist "env.template" (
        copy /Y "env.template" ".env.local" >nul
    )
)

echo.
echo 설치 완료.
echo 다음 단계:
echo 1. .env.local에 API 값을 입력
echo 2. run.bat 더블클릭
echo.
pause
