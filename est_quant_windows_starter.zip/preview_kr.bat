@echo off
setlocal EnableExtensions
chcp 65001 >nul
title EST Quant KR Preview

cd /d "%~dp0"

where uv >nul 2>nul
if errorlevel 1 (
    echo [ERROR] uv가 없습니다. 먼저 install.bat을 실행하세요.
    pause
    exit /b 1
)

uv run --python 3.12 tele-quant briefing --market KR --no-send
pause
